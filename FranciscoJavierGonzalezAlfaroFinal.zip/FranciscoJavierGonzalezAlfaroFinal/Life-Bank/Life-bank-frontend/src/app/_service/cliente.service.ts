import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Cliente }   from '../_model/cliente'

@Injectable({
  providedIn: 'root'
})
export class ClienteService {

  url: string = 'http://private-25a4a0-franciscogonzal2.apiary-mock.com/cliente';

  constructor(private http: HttpClient) { }

  listar(){
  return this.http.get<Cliente[]>(this.url);
}
}
