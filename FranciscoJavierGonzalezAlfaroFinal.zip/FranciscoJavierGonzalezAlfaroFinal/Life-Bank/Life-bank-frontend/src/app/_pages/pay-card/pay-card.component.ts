import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pay-card',
  templateUrl: './pay-card.component.html',
  styleUrls: ['./pay-card.component.css']
})
export class PayCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
