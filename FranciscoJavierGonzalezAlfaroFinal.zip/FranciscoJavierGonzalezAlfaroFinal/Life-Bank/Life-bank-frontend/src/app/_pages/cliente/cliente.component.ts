import { Component, OnInit } from '@angular/core';
import { ClienteService } from 'src/app/_service/cliente.service';
import { Cliente } from 'src/app/_model/cliente';

@Component({
  selector: 'app-pay-credit-card',
  templateUrl: './cliente.component.html',
  //styleUrls: ['./cliente.component.css']
})
export class ClienteComponent implements OnInit {
  cliente: Cliente[]=[];

  constructor(private ClienteService: ClienteService) { }
   
  ngOnInit() {
    this.ClienteService.listar().subscribe(cliente =>{
        this.cliente = cliente;
      });
  }
}
