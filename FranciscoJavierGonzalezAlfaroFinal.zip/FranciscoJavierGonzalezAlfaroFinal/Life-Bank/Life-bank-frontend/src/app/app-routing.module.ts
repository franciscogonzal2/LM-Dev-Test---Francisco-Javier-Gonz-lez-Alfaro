import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {  ClienteComponent } from './_pages/cliente/cliente.component';
import { NotfoundComponent } from './_pages/notfound/notfound.component';
import { LoginComponent } from './_pages/login/login.component';
import { TransferComponent } from './_pages/transfer/transfer.component';
import { LoanComponent } from './_pages/loan/loan.component';
import { PayCardComponent } from './_pages/pay-card/pay-card.component';

const routes: Routes = [
  {path: 'cliente', component: ClienteComponent},
  {path: 'login', component: LoginComponent},
  {path: 'transfer', component: TransferComponent},
  {path: 'pay-loan', component:LoanComponent},
  {path: 'pay-card', component:PayCardComponent},
  {path: '', component: LoginComponent},
  {path: '**', component: NotfoundComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
