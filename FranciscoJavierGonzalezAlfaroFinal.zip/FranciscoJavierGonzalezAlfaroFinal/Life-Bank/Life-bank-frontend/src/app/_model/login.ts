export class  Login 
{
  Header:[{
     imageurl: string;
     title: string;
    }];
    texts: [{
        id: string;
        text: string;
    }];
}