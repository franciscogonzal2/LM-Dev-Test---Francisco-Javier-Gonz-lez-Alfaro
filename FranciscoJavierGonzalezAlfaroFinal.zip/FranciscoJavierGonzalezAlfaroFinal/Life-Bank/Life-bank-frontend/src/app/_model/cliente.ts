export class  Cliente 
 {
    idPaciente: number;
    nombres: string;
    apellidos: string;
    dui: string;
    direccion: string;
    telefono: string;
  }