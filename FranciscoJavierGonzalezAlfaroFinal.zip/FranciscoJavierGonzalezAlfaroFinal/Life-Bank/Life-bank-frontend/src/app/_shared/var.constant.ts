export const HOST='http://localhost:8080';
export const TOKEN_AUTH_USERNAME = 'pruebaapp';
export const TOKEN_AUTH_PASSWORD = 'frank89codex';
export const  TOKEN_NAME ='access_tokes';