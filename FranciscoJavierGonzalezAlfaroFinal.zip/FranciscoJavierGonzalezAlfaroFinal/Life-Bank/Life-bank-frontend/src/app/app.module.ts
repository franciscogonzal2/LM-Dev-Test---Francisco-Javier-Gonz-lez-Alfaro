import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ClienteComponent } from './_pages/cliente/cliente.component';
import { MaterialModule } from './material/material.module';
import { NotfoundComponent } from './_pages/notfound/notfound.component';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './_pages/login/login.component';
import { TransferComponent } from './_pages/transfer/transfer.component';
import { LoanComponent } from './_pages/loan/loan.component';
import { PayCardComponent } from './_pages/pay-card/pay-card.component';
import { MyserviceComponent } from './_pages/myservice/myservice.component'

@NgModule({
  declarations: [
    AppComponent,
    ClienteComponent,
    NotfoundComponent,
    LoginComponent,
    TransferComponent,
    LoanComponent,
    PayCardComponent,
    MyserviceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
