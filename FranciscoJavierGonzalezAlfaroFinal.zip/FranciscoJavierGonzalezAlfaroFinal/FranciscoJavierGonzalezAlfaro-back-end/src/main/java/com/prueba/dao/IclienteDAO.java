package com.prueba.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prueba.model.Cliente;

public interface IclienteDAO extends JpaRepository<Cliente, Integer>{
	
}
