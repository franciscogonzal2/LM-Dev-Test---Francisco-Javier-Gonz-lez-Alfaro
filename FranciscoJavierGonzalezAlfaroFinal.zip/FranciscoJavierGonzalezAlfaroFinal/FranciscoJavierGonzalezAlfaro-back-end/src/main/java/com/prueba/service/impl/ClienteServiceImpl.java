package com.prueba.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prueba.dao.IclienteDAO;
import com.prueba.model.Cliente;
import com.prueba.service.IclienteService;

@Service
public class ClienteServiceImpl implements IclienteService{

	@Autowired
	private IclienteDAO dao;
	
	@Override
	public Cliente registrar(Cliente t) {
		return dao.save(t);
	}

	@Override
	public Cliente modificar(Cliente t) {
		return dao.save(t);
	}

	@Override
	public void eliminar(int id) {
		dao.delete(id);
	}

	@Override
	public Cliente listarId(int id) {
		return dao.findOne(id);
	}

	@Override
	public List<Cliente> listar() {
		return dao.findAll();
	}
}
