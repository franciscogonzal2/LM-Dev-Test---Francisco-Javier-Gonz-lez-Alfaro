package com.prueba.service;

import com.prueba.model.Cliente;

public interface IclienteService extends ICRUD <Cliente> {

}
